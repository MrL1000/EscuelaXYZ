﻿namespace Core.Entities
{
    public class Alumno
    {
        public int IdAlumno { get; set; }
        public string Nombre { get; set; }
        public int Edad { get; set; }
    }
}
