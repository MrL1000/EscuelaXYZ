CREATE DATABASE EscuelaXYZ;
GO

USE EscuelaXYZ
GO

CREATE TABLE Aulas (
    IdAula INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Activo BIT NOT NULL DEFAULT 1, 
    FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(),
    FechaModificacion DATETIME NULL 
)
go

CREATE TABLE Docentes (
    IdDocente INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Activo BIT NOT NULL DEFAULT 1,
    FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(), 
    FechaModificacion DATETIME NULL 
)
go

CREATE TABLE Alumnos (
    IdAlumno INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Edad INT NOT NULL,
    Activo BIT NOT NULL DEFAULT 1, 
    FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(), 
    FechaModificacion DATETIME NULL
)
go

CREATE TABLE DocentesAulas (
    IdDocenteAula INT PRIMARY KEY IDENTITY(1,1),
    IdDocente INT NOT NULL,
    IdAula INT NOT NULL,
    Activo BIT NOT NULL DEFAULT 1,
    FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(), 
    FechaModificacion DATETIME NULL,
    CONSTRAINT FK_DocentesAulas_Docentes FOREIGN KEY (IdDocente) REFERENCES Docentes(IdDocente),
    CONSTRAINT FK_DocentesAulas_Aulas FOREIGN KEY (IdAula) REFERENCES Aulas(IdAula)
)
go

CREATE TABLE AlumnoAula (
	IdAlumnoAula INT PRIMARY KEY IDENTITY(1,1),
    IdAlumno INT,
    IdAula INT,
	Activo BIT NOT NULL DEFAULT 1,
    FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(), 
    FechaModificacion DATETIME NULL,
    FOREIGN KEY (IdAlumno) REFERENCES Alumnos(IdAlumno),
    FOREIGN KEY (IdAula) REFERENCES Aulas(IdAula)
)
go

---> Datos de prueba

INSERT INTO Aulas (Nombre, Activo)
VALUES 
('Aula 101', 1),
('Aula 102', 1),
('Aula 103', 1),
('Aula 104', 1),
('Aula 105', 1),
('Aula 201', 1),
('Aula 202', 1),
('Aula 203', 1),
('Aula 204', 1),
('Aula 205', 1)
go


INSERT INTO Docentes (Nombre, Activo)
VALUES 
('Docente 1', 1),
('Docente 2', 1),
('Docente 3', 1),
('Docente 4', 1),
('Docente 5', 1),
('Docente 6', 1),
('Docente 7', 1),
('Docente 8', 1),
('Docente 9', 1),
('Docente 10', 1)
go

INSERT INTO Alumnos (Nombre, Edad, Activo)
VALUES 
('Alumno 1', 15, 1),
('Alumno 2', 16, 1),
('Alumno 3', 14, 1),
('Alumno 4', 15, 1),
('Alumno 5', 16, 1),
('Alumno 6', 17, 1),
('Alumno 7', 14, 1),
('Alumno 8', 15, 1),
('Alumno 9', 16, 1),
('Alumno 10', 14, 1)
go

INSERT INTO DocentesAulas (IdDocente, IdAula, Activo)
VALUES 
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(9, 9, 1),
(10, 10, 1)
go

INSERT INTO AlumnoAula (IdAlumno, IdAula, Activo)
VALUES 
(1, 1, 1),
(2, 1, 1),
(3, 2, 1),
(4, 2, 1),
(5, 3, 1),
(6, 3, 1),
(7, 4, 1),
(8, 4, 1),
(9, 5, 1),
(10, 5, 1)
go

---> SPs

-- req 1:
CREATE PROCEDURE spObtenerAlumnosPorAula
    @IdAula INT
AS
BEGIN
    SELECT a.IdAlumno, a.Nombre, a.Edad, a.Activo
    FROM Alumnos a
    INNER JOIN AlumnoAula aa ON a.IdAlumno = aa.IdAlumno
    WHERE aa.IdAula = @IdAula AND a.Activo = 1 AND aa.Activo = 1;
END
GO

-- req 2:
CREATE PROCEDURE spObtenerAlumnosPorDocente
    @IdDocente INT
AS
BEGIN
    SELECT a.IdAlumno, a.Nombre, a.Edad, a.Activo
    FROM Alumnos a
    INNER JOIN AlumnoAula aa ON a.IdAlumno = aa.IdAlumno
    INNER JOIN DocentesAulas da ON aa.IdAula = da.IdAula
    WHERE da.IdDocente = @IdDocente AND a.Activo = 1 AND aa.Activo = 1;
END
GO

-- req 3:
CREATE PROCEDURE spAsignarAlumnoAula
    @IdAlumno INT,
    @IdAula INT,
    @Resultado INT OUTPUT,       
    @Mensaje NVARCHAR(255) OUTPUT
AS
BEGIN
    SET @Resultado = 0;
    SET @Mensaje = 'Error al asignar el alumno al aula';

    IF (SELECT COUNT(*) FROM AlumnoAula WHERE IdAula = @IdAula AND Activo = 1) < 5
    BEGIN
        INSERT INTO AlumnoAula (IdAlumno, IdAula, Activo, FechaCreacion)
        VALUES (@IdAlumno, @IdAula, 1, GETDATE());
        
        SET @Resultado = 1;
        SET @Mensaje = 'Alumno asignado correctamente al aula';
    END
    ELSE
    BEGIN
        SET @Mensaje = 'El aula ha alcanzado el m�ximo de 5 alumnos';
    END
END
GO

-- req 4: 
CREATE PROCEDURE spActualizarAlumno
    @IdAlumno INT,
    @Nombre NVARCHAR(100),
    @Edad INT,
    @Resultado INT OUTPUT,
    @Mensaje NVARCHAR(255) OUTPUT
AS
BEGIN
    SET @Resultado = 0;
    SET @Mensaje = 'Error al actualizar el alumno';

    IF EXISTS (SELECT 1 FROM Alumnos WHERE IdAlumno = @IdAlumno AND Activo = 1)
    BEGIN
        UPDATE Alumnos
        SET Nombre = @Nombre,
            Edad = @Edad,
            FechaModificacion = GETDATE()
        WHERE IdAlumno = @IdAlumno;

        SET @Resultado = 1;
        SET @Mensaje = 'Alumno actualizado correctamente';
    END
    ELSE
    BEGIN
        SET @Mensaje = 'El alumno no existe o ha sido eliminado';
    END
END
GO

-- req 5: 
CREATE PROCEDURE spEliminarAlumnoAula
    @IdAlumno INT,
	@IdAula INT,
    @Resultado INT OUTPUT,
    @Mensaje NVARCHAR(255) OUTPUT
AS
BEGIN
    SET @Resultado = 0;
    SET @Mensaje = 'Error al eliminar el alumno';

    IF EXISTS (SELECT 1 FROM Alumnos a
                INNER JOIN AlumnoAula aa ON a.IdAlumno = aa.IdAlumno
                WHERE a.IdAlumno = @IdAlumno AND aa.IdAula = @IdAula AND a.Activo = 1 AND aa.Activo = 1)
    BEGIN
        UPDATE AlumnoAula
        SET Activo = 0, FechaModificacion = GETDATE()
        WHERE IdAlumno = @IdAlumno AND IdAula = @IdAula;

        SET @Resultado = 1;
        SET @Mensaje = 'Alumno eliminado correctamente';
    END
    ELSE
    BEGIN
        SET @Mensaje = 'El alumno no existe o ya ha sido eliminado';
    END
END
GO

-- add:
CREATE PROCEDURE spAsignarDocenteAula
    @IdDocente INT,
    @IdAula INT,
    @Resultado INT OUTPUT,
    @Mensaje NVARCHAR(255) OUTPUT
AS
BEGIN
    SET @Resultado = 0;
    SET @Mensaje = 'Error al asignar el docente al aula';

    IF NOT EXISTS (SELECT 1 FROM DocentesAulas WHERE IdDocente = @IdDocente AND IdAula = @IdAula AND Activo = 1)
    BEGIN
        INSERT INTO DocentesAulas (IdDocente, IdAula, Activo, FechaCreacion)
        VALUES (@IdDocente, @IdAula, 1, GETDATE());

        SET @Resultado = 1;
        SET @Mensaje = 'Docente asignado correctamente al aula';
    END
    ELSE
    BEGIN
        SET @Mensaje = 'El docente ya est� asignado a este aula';
    END
END
GO


-- Usuario BD para prueba t�cnica
USE master
go

CREATE LOGIN PruebaTecnica WITH PASSWORD = 'prU3b4t3cnic4';

USE EscuelaXYZ;  
CREATE USER PruebaTecnica FOR LOGIN PruebaTecnica;

EXEC sp_addrolemember 'db_datareader', 'PruebaTecnica';
EXEC sp_addrolemember 'db_datawriter', 'PruebaTecnica';

GRANT EXECUTE ON SCHEMA::dbo TO PruebaTecnica;

select * from Alumnos
go

select * from AlumnoAula
go

select * from DocentesAulas
go