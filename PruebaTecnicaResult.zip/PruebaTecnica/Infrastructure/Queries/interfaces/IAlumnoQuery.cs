﻿using Core.Entities;

namespace Infrastructure.Queries.interfaces
{
    public interface IAlumnoQuery
    {
        Task<IEnumerable<dynamic>> ObtenerAlumnosPorAula(int idAula);

        Task<IEnumerable<dynamic>> ObtenerAlumnosPorDocente(int idDocente);

        Task<ResultadoOperacion> AsignarAlumnoAula(int idAlumno, int idAula);

        Task<ResultadoOperacion> ActualizarAlumno(Alumno alumno);

        Task<ResultadoOperacion> EliminarAlumnoAula(int idAlumno, int idAula);

        Task<ResultadoOperacion> AsignarDocenteAula(int idDocente, int idAula);
    }
}
