﻿using Core.Entities;
using Dapper;
using Infrastructure.Queries.interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace Infrastructure.Queries
{
    public class AlumnoQuery : IAlumnoQuery
    {
        private readonly string _connectionString;
        private readonly ILogger<AlumnoQuery> _logger;

        public AlumnoQuery(IConfiguration configuration, ILogger<AlumnoQuery> logger)
        {
            _connectionString = configuration.GetConnectionString("PruebaTecnicaDB");
            _logger = logger;
        }

        public async Task<IEnumerable<dynamic>> ObtenerAlumnosPorAula(int idAula)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("IdAula", idAula);

                    return await connection.QueryAsync<dynamic>(
                        "spObtenerAlumnosPorAula",
                        parameters,
                        commandType: CommandType.StoredProcedure
                    );
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al obtener alumnos por aula {idAula}: {ex.Message}");
                throw;
            }
        }

        public async Task<IEnumerable<dynamic>> ObtenerAlumnosPorDocente(int idDocente)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("IdDocente", idDocente);

                    return await connection.QueryAsync<dynamic>(
                        "spObtenerAlumnosPorDocente",
                        parameters,
                        commandType: CommandType.StoredProcedure
                    );
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al obtener alumnos por docente {idDocente}: {ex.Message}");
                throw;
            }
        }

        public async Task<ResultadoOperacion> AsignarAlumnoAula(int idAlumno, int idAula)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("IdAlumno", idAlumno);
                    parameters.Add("IdAula", idAula);
                    parameters.Add("Resultado", dbType: DbType.Int32, direction: ParameterDirection.Output);
                    parameters.Add("Mensaje", dbType: DbType.String, size: 255, direction: ParameterDirection.Output);

                    await connection.ExecuteAsync(
                        "spAsignarAlumnoAula",
                        parameters,
                        commandType: CommandType.StoredProcedure
                    );

                    var resultado = parameters.Get<int>("Resultado") == 1;
                    var mensaje = parameters.Get<string>("Mensaje");

                    return new ResultadoOperacion
                    {
                        Resultado = resultado,
                        Mensaje = mensaje
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al asignar alumno {idAlumno} al aula {idAula}: {ex.Message}");
                throw;
            }
        }

        public async Task<ResultadoOperacion> ActualizarAlumno(Alumno alumno)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("IdAlumno", alumno.IdAlumno);
                    parameters.Add("Nombre", alumno.Nombre);
                    parameters.Add("Edad", alumno.Edad);
                    parameters.Add("Resultado", dbType: DbType.Int32, direction: ParameterDirection.Output);
                    parameters.Add("Mensaje", dbType: DbType.String, size: 255, direction: ParameterDirection.Output);

                    await connection.ExecuteAsync(
                        "spActualizarAlumno",
                        parameters,
                        commandType: CommandType.StoredProcedure
                    );

                    var resultado = parameters.Get<int>("Resultado") == 1;
                    var mensaje = parameters.Get<string>("Mensaje");

                    return new ResultadoOperacion
                    {
                        Resultado = resultado,
                        Mensaje = mensaje
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al actualizar alumno {alumno.IdAlumno}: {ex.Message}");
                throw;
            }
        }

        public async Task<ResultadoOperacion> EliminarAlumnoAula(int idAlumno, int idAula)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("IdAlumno", idAlumno);
                    parameters.Add("IdAula", idAula);
                    parameters.Add("Resultado", dbType: DbType.Int32, direction: ParameterDirection.Output);
                    parameters.Add("Mensaje", dbType: DbType.String, size: 255, direction: ParameterDirection.Output);

                    await connection.ExecuteAsync(
                        "spEliminarAlumnoAula",
                        parameters,
                        commandType: CommandType.StoredProcedure
                    );

                    var resultado = parameters.Get<int>("Resultado") == 1;
                    var mensaje = parameters.Get<string>("Mensaje");

                    return new ResultadoOperacion
                    {
                        Resultado = resultado,
                        Mensaje = mensaje
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al eliminar alumno {idAlumno} del aula {idAula}: {ex.Message}");
                throw;
            }
        }

        public async Task<ResultadoOperacion> AsignarDocenteAula(int idDocente, int idAula)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("IdDocente", idDocente);
                    parameters.Add("IdAula", idAula);
                    parameters.Add("Resultado", dbType: DbType.Int32, direction: ParameterDirection.Output);
                    parameters.Add("Mensaje", dbType: DbType.String, size: 255, direction: ParameterDirection.Output);

                    await connection.ExecuteAsync(
                        "spAsignarDocenteAula",
                        parameters,
                        commandType: CommandType.StoredProcedure
                    );

                    var resultado = parameters.Get<int>("Resultado") == 1;
                    var mensaje = parameters.Get<string>("Mensaje");

                    return new ResultadoOperacion
                    {
                        Resultado = resultado,
                        Mensaje = mensaje
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al asignar docente {idDocente} al aula {idAula}: {ex.Message}");
                throw;
            }
        }
    }
}
