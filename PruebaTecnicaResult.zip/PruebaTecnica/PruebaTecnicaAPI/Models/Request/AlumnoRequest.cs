﻿namespace PruebaTecnicaAPI.Models.Request
{
    public class AlumnoRequest
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
    }
}
