﻿namespace PruebaTecnicaAPI.Models.Dto
{
    public class AsignarAlumnoDto
    {
        public int IdAlumno { get; set; }
        public int IdAula { get; set; }
    }
}
