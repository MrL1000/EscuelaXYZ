﻿namespace PruebaTecnicaAPI.Models.Dto
{
    public class AsignarDocenteDto
    {
        public int IdDocente { get; set; }
        public int IdAula { get; set; }
    }
}
