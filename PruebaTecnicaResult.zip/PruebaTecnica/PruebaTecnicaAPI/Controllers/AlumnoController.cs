﻿using Microsoft.AspNetCore.Mvc;
using Infrastructure.Queries.interfaces;
using Core.Entities;
using PruebaTecnicaAPI.Models.Dto;
using PruebaTecnicaAPI.Models.Request;
using Microsoft.Extensions.Logging;
using System;

namespace PruebaTecnicaAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlumnoController : ControllerBase
    {
        private readonly IAlumnoQuery _alumnoQuery;
        private readonly ILogger<AlumnoController> _logger;

        public AlumnoController(IAlumnoQuery alumnoQuery, ILogger<AlumnoController> logger)
        {
            _alumnoQuery = alumnoQuery;
            _logger = logger;
        }

        // Req 1: 
        [HttpGet("alumnosPorAula/{idAula}")]
        public async Task<IActionResult> ObtenerAlumnosPorAula(int idAula)
        {
            try
            {
                var alumnos = await _alumnoQuery.ObtenerAlumnosPorAula(idAula);
                return Ok(alumnos);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al obtener alumnos del aula {idAula}: {ex.Message}");
                return StatusCode(500, "Error interno del servidor");
            }
        }

        // Req 2:
        [HttpGet("alumnosPorDocente/{idDocente}")]
        public async Task<IActionResult> ObtenerAlumnosPorDocente(int idDocente)
        {
            try
            {
                var alumnos = await _alumnoQuery.ObtenerAlumnosPorDocente(idDocente);
                return Ok(alumnos);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error al obtener alumnos del docente {idDocente}: {ex.Message}");
                return StatusCode(500, "Error interno del servidor");
            }
        }

        // Req 3: 
        [HttpPost("asignarAlumnoAula")]
        public async Task<IActionResult> AsignarAlumnoAula([FromBody] AsignarAlumnoDto dto)
        {
            var result = await _alumnoQuery.AsignarAlumnoAula(dto.IdAlumno, dto.IdAula);
            if (result.Resultado)
            {
                return Ok(new { Message = result.Mensaje });
            }
            return BadRequest(new { Message = result.Mensaje });
        }

        // Req 4:
        [HttpPut("actualizarAlumno/{idAlumno}")]
        public async Task<IActionResult> ActualizarAlumno(int idAlumno, [FromBody] AlumnoRequest request)
        {
            Alumno alumno = new Alumno
            {
                IdAlumno = idAlumno,
                Nombre = request.Nombre,
                Edad = request.Edad,
            };

            var result = await _alumnoQuery.ActualizarAlumno(alumno);
            if (result.Resultado)
            {
                return Ok(new { Message = result.Mensaje });
            }
            return BadRequest(new { Message = result.Mensaje });
        }

        // Req 5:
        [HttpDelete("eliminarAlumnoAula/{idAlumno}/{idAula}")]
        public async Task<IActionResult> EliminarAlumnoAula(int idAlumno, int idAula)
        {
            var result = await _alumnoQuery.EliminarAlumnoAula(idAlumno, idAula);
            if (result.Resultado)
            {
                return Ok(new { Message = result.Mensaje });
            }
            return BadRequest(new { Message = result.Mensaje });
        }

        //add
        [HttpPost("asignarDocenteAula")]
        public async Task<IActionResult> AsignarDocenteAula([FromBody] AsignarDocenteDto dto)
        {
            var result = await _alumnoQuery.AsignarDocenteAula(dto.IdDocente, dto.IdAula);
            if (result.Resultado)
            {
                return Ok(new { Message = result.Mensaje });
            }
            return BadRequest(new { Message = result.Mensaje });
        }
    }
}
